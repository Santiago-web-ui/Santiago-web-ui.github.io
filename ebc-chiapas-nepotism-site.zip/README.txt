﻿EBC CHIAPAS REPORT - HOW TO OPEN

1. EASIEST / MOST PORTABLE
   Open: ebc-chiapas-nepotism-report-standalone.html
   Videos, posters, and the campus image are embedded in this file.
   It does not need the media folder.

2. EDITABLE VERSION
   Open: ebc-chiapas-nepotism-report.html
   Keep the media folder in the same directory.

CONTENT NOTES
- Five tabs: Summary, Context, Testimonies, Analysis, Action.
- Legal notice and corrections policy are in Take Action; a footer link
  opens the notice from any tab.
- About us: Santiago Hernandez and Patricio Moscoso.
- Campus image supplied for this project; caption identifies it.
- Participants are not named. Confirm documented consent from everyone
  visible or audible before public release, or anonymize/blur.
- Spanish passages were transcribed locally and translated editorially.
  Check exact wording against the recordings before publication.
- The contact form is a non-transmitting placeholder.
- Allegations and perceptions only; not a legal finding.
